import java.io.Serializable;
/***
 * this POJO class is used to store and retrieve file-related information
 * such as filename, filelocation to client-server. 
 * it has filename and filelocation as field. 
 */
public class FileInfo implements Serializable{

	private String fileName;
	private String fileLocation;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	
	
	
}
