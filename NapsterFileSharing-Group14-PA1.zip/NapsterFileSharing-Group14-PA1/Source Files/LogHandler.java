import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/***
 * This class provides various methods to create logs.
 */
public class LogHandler {

	private String logFileName = "";
	private BufferedWriter bufOut = null;
	private final String logFileLocation = "logs/";

/***
 * Constructor for creating log file object
 * @param logType
 */
	public LogHandler(String logType) {
		try {
			if (logType.equalsIgnoreCase("Peer")) {//check logtype and accordingly create log file.
				logFileName = "peerdownload.log";
			} else if (logType.equalsIgnoreCase("Server")) {
				logFileName = "server.log";
			}
			
			File file = new File(logFileLocation);
			
			if (!file.exists()){//create folder logs if not exists
				file.mkdir();
			}
			
			bufOut = new BufferedWriter(new FileWriter(logFileLocation + logFileName, true));
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***
	 * this method writes log text to the file log
	 * @param logMsg text to be appended in log file
	 * @return boolean // return true if successfull
 	 */
	public boolean writeLog(String logMsg) {
		boolean writeFlag = false;
		try {
			String timeLog = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
			if (bufOut != null) {
				logMsg = String.format("%s => %s", timeLog, logMsg);
				bufOut.write(logMsg);
				String newline = System.getProperty("line.separator");
				bufOut.write(newline);
				writeFlag = true;
				bufOut.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return writeFlag;
	}
	
	/***
	 * This method close the file stream so that the log file can be accessed by other methods.
	 */
	public void closeLogFile() {
		try {
			if (bufOut != null) {
				String lineSeparator = System.getProperty("line.separator");
				bufOut.write(lineSeparator);
				bufOut.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/***
	 * This method acts as destructor. it is called when the garbage collector is called. 
	 */
	@Override
	protected void finalize() throws Throwable {
		if (bufOut != null) {
			bufOut.close();
		}
		super.finalize();
	}
	
}