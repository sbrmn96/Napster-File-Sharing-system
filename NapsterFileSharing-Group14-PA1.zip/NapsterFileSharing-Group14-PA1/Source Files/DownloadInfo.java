import java.io.Serializable;

/***
 * this POJO class is used by indexing server to provide Download-related information 
 * like peerId,peer Ip, file name, filelocation. 
 * it has PeerInfo and FileInfo as field. 
 */
public class DownloadInfo implements Serializable{
private PeerInfo peerInfo;
private FileInfo fileInfo;
public PeerInfo getPeerInfo() {
	return peerInfo;
}
public void setPeerInfo(PeerInfo peerInfo) {
	this.peerInfo = peerInfo;
}
public FileInfo getFileInfo() {
	return fileInfo;
}
public void setFileInfo(FileInfo fileInfo) {
	this.fileInfo = fileInfo;
}

}
