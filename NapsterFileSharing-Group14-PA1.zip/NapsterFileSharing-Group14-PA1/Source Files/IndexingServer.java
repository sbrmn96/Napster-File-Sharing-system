import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;

/***
 * This class is used to handle requests from peers to lookup files,register/unregister files,
 * close connection.
 * Also it periodically synchronize indexing map by sending requests to all peers.
 */

public class IndexingServer {
	
	static int peerId=0;
	/***
	 * peerList is hashmap used to store registered-peer-related information.each peer sharing different
	 * directory is considered as different value in map.
	 * fileList is hashmap used to store shared-file-related information for each peers.
	 */
	private static HashMap<Integer, PeerInfo> peerList=new HashMap<Integer,PeerInfo>();
	private static HashMap<Integer, ArrayList<FileInfo>> fileList=new HashMap<Integer,ArrayList<FileInfo>>();
	private static final int INDEX_SERVER_PORT=10000;//listening port for requests from peer
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			//int peerId=1;
			ServerSocket serverSocket=new ServerSocket(INDEX_SERVER_PORT);
			System.out.println("Indexing Server Started!!!");
			System.out.println("Waiting for new connection from peer!!!");
			System.out.println();
			try{
				new Index2PeerFileSync().start();
					
				while(true)
				{
					new IndexServer(serverSocket.accept()).start();
				}
			}
			finally{
				serverSocket.close();
			}
	}
	
	/***
	 * This class is used to create a seperate thread for synchronization of shared files for all the peer. 
	 */
	private static class Index2PeerFileSync extends Thread {
		
		public void run()
		{
			while(true)
			{	
				
				String syncIp=null,syncLocation=null;
				Communicator res=new Communicator();
				try{
					Index2PeerFileSync.sleep(60000);
					//send requests to all the peers from hashmap.
					for(int pi : peerList.keySet()) {
						PeerInfo peerinfo=peerList.get(pi);
						syncIp=peerinfo.getIp();
						syncLocation=peerinfo.getDirectory();
						Socket clientsyncsocket = new Socket(syncIp, Peer.PEER_LISTEN_PORT);
						ObjectOutputStream serversyncoutput = new ObjectOutputStream(clientsyncsocket.getOutputStream());
						ObjectInputStream serversyncinput = new ObjectInputStream(clientsyncsocket.getInputStream());
						res.setCommunicatorType("FileSync");
						res.setCommunicatorInfo(peerinfo);
						serversyncoutput.writeObject(res);
						
						res = (Communicator) serversyncinput.readObject();
						ArrayList<FileInfo> afl=(ArrayList<FileInfo>)res.getCommunicatorInfo();
						if(afl.isEmpty())
						{
							fileList.remove(pi);
						}
						else
						{
							fileList.put(pi, afl);//put updated arraylist of fileInfo in hashmap
						}
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}	
		}	
	}

	 // A private thread to handle peer's file sharing requests on a particular socket.
	private static class IndexServer extends Thread {
		
		Socket clientSocket;
		String ipAddress;
		ObjectOutputStream serveroutput=null;
		ObjectInputStream serverinput=null;
		LogHandler log;
		Communicator res;
		public IndexServer(Socket clientSocket) throws IOException
		{	
			this.clientSocket=clientSocket;
			ipAddress=clientSocket.getInetAddress().getHostAddress();
			System.out.println("Connection Estaiblished with Peer having IP "
			+clientSocket.getInetAddress());
			
			printLog("Connection Estaiblished with Peer having IP "
			+clientSocket.getInetAddress());
			
		}
		
		/***
		 *this method is used to append messages to the server.log file. 
		 */
		 
		public void printLog(String msg)
		{
			log=new LogHandler("server");
			log.writeLog(msg);
			log.closeLogFile();
		}
		
		/**
		 * Services this thread's client by first sending the client a welcome
		 * message then repeatedly reading requests from the peer.
		 */
		public void run()
		{	
			
			try {
				// Initializing output stream using the socket's output stream
				serveroutput = new ObjectOutputStream(clientSocket.getOutputStream());
				serveroutput.flush();
				
				// Initializing input stream using the socket's input stream
				serverinput=new ObjectInputStream(clientSocket.getInputStream());
				res=new Communicator();
				
				//send welcome method to the peer.
				res.setCommunicatorInfo("Welcome to the P2P File Sharing System!! "
						+ "Please choose from below options of your choice");
				serveroutput.writeObject(res);
				serveroutput.flush();
				
				while(true){
					// Read the communicator object received from the Peer
					String choice=null;
					res=(Communicator)serverinput.readObject();
					choice = res.getCommunicatorType().toString();
					if(!choice.equals("UNREGISTER") && !choice.equals("CLOSE"))
					{	
						serveroutput.writeObject(res);
						serveroutput.flush();
					}
					
					//call methods according to communicatortype field received from peer. 
					switch(choice){
						case "REGISTERPEER":
							peerConnection();
							break;
						case "LOOKUPFILE":
							peerFileLookup();
							break;
						case "LOOKUPPRINTFILE":
							peerFileLookupPrint();
							break;
						case "UNREGISTER":
							peerUnregister(res);
							break;	
						case "CLOSE" :
							peerClose(res);
							break;
						default:
							break;
					}
					
				}//end while(true)
				
			}
			catch(SocketException e)
			{
				System.out.println("Connection with IP: "+ipAddress+" terminated\n");
			}
			catch(EOFException e)
			{
				System.out.println("PerformanceTest connection terminated!");
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/***
		 * this method is used for connecting socket acception from peer.
		 * This method is also used to register peer with indexing server  
		 */
		public void peerConnection()
		{
			int flag=0;
			String dirCheck=null;
			try {
					Communicator res=new Communicator();
					printLog("Peer with IP: "+ipAddress+" connected.");
					res=(Communicator)serverinput.readObject();
					
					if(res.getCommunicatorType().equals("Peercheck"))
					{
						dirCheck=res.getCommunicatorInfo().toString();
				
						for (int pi : peerList.keySet()) {//check if peer has previously connected or not.
							PeerInfo peerInfo=peerList.get(pi);
							if(peerInfo.getIp().equals(ipAddress) && peerInfo.getDirectory().equals(dirCheck))
							{
								flag=1;
								break;
							}
						} 
						
					}
					if(flag==0)//if not, put peerInfo in hashmap and register peer.
					{
						PeerInfo peer=new PeerInfo();
						peerId++;
						peer.setPeerId(peerId);
						peer.setIp(ipAddress);
						peer.setDirectory(dirCheck);
						peerList.put(peerId, peer);
						serveroutput.writeObject(res);
					}
					else{
						
						serveroutput.writeObject(res);
					}
					
					res=(Communicator)serverinput.readObject();
	
					switch(res.getCommunicatorType().toString())
					{
						case "Register":
							peerRegister(res);
							break;
						default :
							break;
					}
					
				}
				catch(SocketException e)
				{
					System.out.println("Connection with IP: "+ipAddress+" terminated\n");
					printLog("Connection with IP: "+ipAddress+" terminated");
				}
				catch (Exception e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}

		}
		
		/***
		 * This method is used to registering files with indexing server  
		 * @param comm
		 */
		private void peerRegister(Communicator comm)
		{
			printLog("Register request from "+ipAddress);
			Communicator res=new Communicator();
			ArrayList<FileInfo> fileInfo=(ArrayList<FileInfo>)comm.getCommunicatorInfo();
			fileList.put(peerId, fileInfo);//put file-related info for peer in the hashmap
			System.out.println("All the files are registered for Peer #"+peerId);
			
			res.setCommunicatorType("registrationSuccessfull");
			res.setCommunicatorInfo("Peer registered with given files successfully...!!!");
			printLog("Files registered succesfully.");
			try {
				serveroutput.writeObject(res);
				serveroutput.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		/***
		 * This method is used when file-lookup request is received from peer.
		 */
		private void peerFileLookup()
		{
			
			String lookupFileName=null;
			ArrayList<PeerInfo> alf=new ArrayList<PeerInfo>();
			HashMap<PeerInfo, ArrayList<FileInfo>> lookMap=new HashMap<PeerInfo,ArrayList<FileInfo>>();//resulted lookup map
			int flag=0;
		try {
			res = (Communicator)serverinput.readObject();//read filename from peer.			
			if(res.getCommunicatorType().equals("lookupFileName"))
			{
				lookupFileName=res.getCommunicatorInfo().toString();
				printLog("Lookup request for File: " +lookupFileName);
			}
			
			for (int pi : fileList.keySet()) {
				ArrayList<FileInfo> fi=fileList.get(pi);
				ArrayList<FileInfo> resArl=new ArrayList<FileInfo>();
				for(FileInfo fInfo : fi)
				{
					if(fInfo.getFileName().equals(lookupFileName))
					{
						resArl.add(fInfo);
						flag=1;
					}
				} 
				if(flag==1)
				{
					PeerInfo peer=peerList.get(pi);
					lookMap.put(peer, resArl);
				}
			}
			
			
			if(lookMap.isEmpty())
			{
				printLog("File: "+lookupFileName+" Not Found.");
			}
			
			serveroutput.flush();
			res.setCommunicatorType("LookupMap");
			
			res.setCommunicatorInfo(lookMap);
			
			serveroutput.writeObject(res);//send lookmap consisting of fileInfo objects to the peer.
			serveroutput.flush();
		
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		/***
		 * This method is used when file-lookup and print request is received from peer.
		 */
		private void peerFileLookupPrint()
		{
			Communicator res;
			String lookupFileName=null;
			ArrayList<PeerInfo> alf=new ArrayList<PeerInfo>();
			HashMap<PeerInfo, ArrayList<FileInfo>> lookMap=new HashMap<PeerInfo,ArrayList<FileInfo>>();
			int flag=0;
		try {
			res = (Communicator)serverinput.readObject();		//read filename from peer.	
			if(res.getCommunicatorType().equals("lookupPrintFileName"))
			{
				lookupFileName=res.getCommunicatorInfo().toString();
				printLog("Lookup request for File: " +lookupFileName);
			}
			
			for (int pi : fileList.keySet()) {
				ArrayList<FileInfo> fi=fileList.get(pi);
				ArrayList<FileInfo> resArl=new ArrayList<FileInfo>();
				for(FileInfo fInfo : fi)
				{
					if(fInfo.getFileName().equals(lookupFileName))
					{
						resArl.add(fInfo);
						flag=1;
					}
				} 
				if(flag==1)
				{
					PeerInfo peer=peerList.get(pi);
					lookMap.put(peer, resArl);
				}
			}
			
			res.setCommunicatorType("LookupPrintMap");
			res.setCommunicatorInfo(lookMap);
			if(lookMap.isEmpty())
			{
				printLog("File: "+lookupFileName+" Not Found.");
			}
			serveroutput.writeObject(res);//send resultant lookupmap to the peer
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
			
		/***
		 * This method is called when Unregister request is received from peer.
		 * @param res
		 */
		public void peerUnregister(Communicator res)
		{
			printLog("Unregister request from "+ipAddress);
			try{
				int isShared=1;
				serveroutput.flush();
				
					for (int pi : peerList.keySet())
					{
						PeerInfo peerinfo=peerList.get(pi);
						if(peerinfo.getIp().equals(ipAddress))
						{
							fileList.remove(pi);//remove all fileInfo object from hashmap for current peer.
							isShared=0;
						}
					}
					
					//send response of completion to peer.
					if(isShared==0) {
						res.setCommunicatorType("UnregisterSuccessfull");
						res.setCommunicatorInfo((String)"Files unregistered successfully!!!\nPlease select options 1 if you want to share any files.");
						serveroutput.writeObject(res);
						printLog("Files unregister successfully.");
						isShared=1;
						
					}
					else{
						res.setCommunicatorType("NotShared");
						res.setCommunicatorInfo((String)"Sorry you haven't shared any files! Select to option 1 to register/share any files");
						serveroutput.writeObject(res);
						printLog("No files found for unregistration");
					}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		/***
		 * This method is called when close connection request is received from peer
		 * @param res
		 */
		public void peerClose(Communicator res)
		{
			printLog("Peer closing request from "+ipAddress);
			try{
				int isShared=1;
				serveroutput.flush();
				
					for (int pi : peerList.keySet())
					{
						PeerInfo peerinfo=peerList.get(pi);
						if(peerinfo.getIp().equals(ipAddress))
						{
							//remove peerInfo and fileInfo object from hashmap indexing database
							peerList.remove(pi);
							fileList.remove(pi);
							isShared=0;
						}
					}
					
					//send terminate response to peer.
					res.setCommunicatorType("CloseSuccessfull");
					res.setCommunicatorInfo((String)"Thankyou for Using Napster");
					serveroutput.writeObject(res);
					printLog("Peer closing request completed for "+ipAddress);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}
	
	
	
}
